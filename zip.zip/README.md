### Importar archivos CSV y Excel a MySQL sin librerías con PHP

#### La forma más facíl de importar archivos CSV y Excel a MySQL sin librerías, es un proyecto que vale la pena mirar pues es una tarea muy codiana.

![](https://raw.githubusercontent.com/urian121/imagenes-proyectos-github/master/importar-csv-a-mysql-con-php.png)
